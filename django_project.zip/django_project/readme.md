# Project powered by Django

### Run project
`python manage.py runserver`

### Create a new app
`python manage.py startapp app_name path/to/dir`

### Full command list
`python manage.py --help`
